/*
Segment.h - Library for 7 segment display common cathode
Created by Mehrdad Asi.
*/
#include "Arduino.h"

//#ifndef Segment_h
//#define Segment_h


// creating a class that we will call in Arduino IDE
class Segment 
{
// functions that user of the library works with
public:
Segment(uint8_t pinA, uint8_t pinB, uint8_t pinC, uint8_t pinD, uint8_t pinE, uint8_t pinF, uint8_t pinG, uint8_t pinDot); 
void Segment_Number(int n); // function 
void Segment_Dot_Point(); // function  
void Segment_Off(); // function 
// internal variables
private:
uint8_t pin_A;
uint8_t pin_B;
uint8_t pin_C;
uint8_t pin_D;
uint8_t pin_E;
uint8_t pin_F;
uint8_t pin_G;
uint8_t pin_Dot;
bool b;
};

//#endif
