/*
Segment.h - Library for 7 segment display common cathode
Created by Mehrdad Asi.
*/

#include "Arduino.h"
#include "7Segment.h"

Segment::Segment(uint8_t pinA, uint8_t pinB, uint8_t pinC, uint8_t pinD, uint8_t pinE, uint8_t pinF, uint8_t pinG, uint8_t pinDot)
{
pinMode(pinA, OUTPUT);
pinMode(pinB, OUTPUT);
pinMode(pinC, OUTPUT);
pinMode(pinD, OUTPUT);
pinMode(pinE, OUTPUT);
pinMode(pinF, OUTPUT);
pinMode(pinG, OUTPUT);
pinMode(pinDot, OUTPUT);
//
pin_A = pinA;
pin_B = pinB;
pin_C = pinC;
pin_D = pinD;
pin_E = pinE;
pin_F = pinF;
pin_G = pinG;
pin_Dot = pinDot;
//
b = false;
}

void Segment::Segment_Number(int n)
{

switch(n)
{
case 0:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 1);
digitalWrite(pin_F, 1);
digitalWrite(pin_G, 0);
digitalWrite(pin_Dot, 0);
break;

case 1:
digitalWrite(pin_A, 0);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 0);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 0);
digitalWrite(pin_G, 0);
digitalWrite(pin_Dot, 0);
break;

case 2:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 0);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 1);
digitalWrite(pin_F, 0);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;

case 3:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 0);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;

case 4:
digitalWrite(pin_A, 0);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 0);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 1);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;

case 5:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 0);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 1);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;

case 6:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 0);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 1);
digitalWrite(pin_F, 1);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;

case 7:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 0);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 0);
digitalWrite(pin_G, 0);
digitalWrite(pin_Dot, 0);
break;

case 8:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 1);
digitalWrite(pin_F, 1);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;

case 9:
digitalWrite(pin_A, 1);
digitalWrite(pin_B, 1);
digitalWrite(pin_C, 1);
digitalWrite(pin_D, 1);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 1);
digitalWrite(pin_G, 1);
digitalWrite(pin_Dot, 0);
break;
}
}

void Segment::Segment_Dot_Point()
{
b = !b;
digitalWrite(pin_Dot, b);
}

void Segment::Segment_Off()
{
digitalWrite(pin_A, 0);
digitalWrite(pin_B, 0);
digitalWrite(pin_C, 0);
digitalWrite(pin_D, 0);
digitalWrite(pin_E, 0);
digitalWrite(pin_F, 0);
digitalWrite(pin_G, 0);
digitalWrite(pin_Dot, 0);
}